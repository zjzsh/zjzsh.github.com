package com.example.wuziqi;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;

/**
 * Created by ydkf051 on 2018/1/3.
 */

public class denglu extends Activity{
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void ck(View v){
        onCreate(null);
    }
    public void edit(View v){
        finish();
    }
}
